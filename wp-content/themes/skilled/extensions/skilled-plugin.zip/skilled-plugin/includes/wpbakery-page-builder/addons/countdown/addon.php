<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Countdown {

	protected $namespace = 'linp_countdown';

	function __construct() {
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ) );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
	}

	public function integrateWithVC() {
		vc_map( array(
			'name'        => esc_html( 'Countdown', 'skilled-plugin' ),
			'description' => '',
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'skilled-plugin' ),
			'params'      => array(

				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Target Date', 'skilled-plugin' ),
					'description' => esc_html__( 'Enter date in this format: 2020/10/10 12:00:00.', 'skilled-plugin' ),
					'param_name'  => 'target_date',
					'value'       => '2020/10/10 12:00:00',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Labels', 'skilled-plugin' ),
					'description' => esc_html__( 'Comma separated list of labels (weeks, days, hours, minutes, seconds).', 'skilled-plugin' ),
					'param_name'  => 'labels',
					'value'       => 'weeks, days, hours, minutes, seconds',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Label Translations', 'skilled-plugin' ),
					'description' => esc_html__( 'Comma separated list of label translations. They must match the number of labels above.', 'skilled-plugin' ),
					'param_name'  => 'label_translations',
					'value'       => '',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
				),
			)
		) );
	}

	public function render( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'target_date'        => '2020/10/10 12:00:00',
			'labels'             => 'weeks, days, hours, minutes, seconds',
			'label_translations' => '',
			'el_class'           => '',

		), $atts ) );

		// $content = wpb_js_remove_wpautop($content); // fix unclosed/unwanted paragraph tags in $content

		$id        = uniqid( 'countdown-' );
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'linp-countdown ' . $el_class, $this->namespace, $atts );

		ob_start();

		$args = array(
			'id' => $id,
			'options' => array(
				'targetDate' => $target_date,
				'labels' => $labels,
				'labelTranslations' => $label_translations,
			)
		);

		?>
		<div class="<?php echo esc_attr( $css_class ); ?>"
			data-date="<?php echo esc_attr( $target_date ) ?>"
			data-labels="<?php echo esc_attr( $labels ) ?>"
			data-translations="<?php echo esc_attr( $label_translations ) ?>"></div>
		<?php

		wp_enqueue_script( 'plugin-countdown-addon' );
		$content = ob_get_clean();

		return $content;
	}

	public function loadCssAndJs() {
		wp_register_script( 'jquery-countdown', plugins_url( 'assets/jquery.countdown.min.js', __FILE__ ), array(
			'jquery',
			'underscore'
		) );
		wp_register_script( 'plugin-countdown-addon', plugins_url( 'assets/countdown.js', __FILE__ ), array(
			'jquery-countdown',
		) );
	}

}

new Skilled_Plugin_VC_Addon_Countdown();
