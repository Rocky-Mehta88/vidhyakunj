<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Courses_Search_Form {

	protected $namespace = 'dntp_courses_search_form';

	function __construct() {
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ) );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
	}

	public function integrateWithVC() {
		vc_map( array(
			'name'        => esc_html__( 'Course Search Form', 'skilled-plugin' ),
			'description' => '',
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'js_composer' ),
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Search Form Type', 'skilled-plugin' ),
					'param_name' => 'form_type',
					'value'      => array(
						'Small'             => 'small',
						'Small (no button)' => 'small_input_only',
						'Big'               => 'big',

					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
				),
			)
		) );
	}

	public function render( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'form_type' => 'small',
			'position'  => '',
			'el_class'  => '',
		), $atts ) );

		// $content = wpb_js_remove_wpautop($content); // fix unclosed/unwanted paragraph tags in $content

		ob_start();
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'dntp-search-courses-form ' . $el_class, $this->namespace, $atts );
		?>

		<div class="<?php echo esc_attr( $css_class ); ?>">
			<?php
			if ( $form_type == 'big' ) {
				$template = locate_template( 'templates/searchform-courses-big.php' );
			} elseif ( $form_type == 'small_input_only' ) {
				$template = locate_template( 'templates/searchform-courses-input-only.php' );
			} else {
				$template = locate_template( 'templates/searchform-courses-small.php' );
			}
			if ( file_exists( $template ) ) {
				include $template;
			}
			?>
		</div>
		<?php
		$content = ob_get_clean();

		return $content;
	}

}

new Skilled_Plugin_VC_Addon_Courses_Search_Form();
