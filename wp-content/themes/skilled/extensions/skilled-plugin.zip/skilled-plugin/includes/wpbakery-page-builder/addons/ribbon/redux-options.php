<?php

$sections[] = array(
        'title' => esc_html__('Calendar Widget', 'skilled-plugin'),
        'subsection' => true,
        'fields' => array(

        	array(
			    'id'          => 'dntp-calendar-widget-title-typography',
			    'type'        => 'typography', 
			    'title'       => esc_html__('Title Typography', 'skilled-plugin'),
			    'google'      => true, 
			    'font-backup' => true,
			    'output'      => array('.dntp-calendar-widget .title'),
			    'units'       =>'px',
			    'default'     => array(
			        'color'       => '#333', 
			        'font-style'  => '700', 
			        'font-family' => 'Abel', 
			        'google'      => true,
			        'font-size'   => '33px', 
			        'line-height' => '40px'
			    ),
			),
		

    	)
    );
