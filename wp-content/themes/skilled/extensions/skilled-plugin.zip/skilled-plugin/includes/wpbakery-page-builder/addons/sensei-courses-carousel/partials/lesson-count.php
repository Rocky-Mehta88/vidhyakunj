<div class="cbp-row">
	<div class="one whole">
		<div class="course-lesson-count">			
			<i class="icon-skilledtime4"></i>
        	<?php echo wp_kses_post( $woothemes_sensei->post_types->course->course_lesson_count( $post_id ) . '&nbsp;' . apply_filters( 'sensei_lessons_text', esc_html__( 'Lessons', 'woothemes-sensei' ) ) ); ?>
		</div>
        <div class="course-lesson-count author">
        	<i class="icon-skilledround-account-button-with-user-inside2"></i>
        	<?php echo wp_kses_post( get_the_author() ); ?>
        </div>
	</div>
</div>