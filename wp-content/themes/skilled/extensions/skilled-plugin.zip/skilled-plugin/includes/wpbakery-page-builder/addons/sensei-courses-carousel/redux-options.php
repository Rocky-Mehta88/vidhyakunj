<?php

$sections[] = array(
	'title'      => esc_html__( 'Sensei Courses Carousel', 'skilled-plugin' ),
	'subsection' => true,
	'fields'     => array(
		array(
			'id'          => 'linp-featured-courses-item-title-typography',
			'type'        => 'typography',
			'title'       => esc_html__( 'Title Typography', 'skilled-plugin' ),
			'google'      => true,
			'font-backup' => true,
			'text-transform' => true,
			'compiler'    => array( '.linp-featured-courses-carousel .course-title, .linp-featured-courses-carousel .course-title a' ),
			'units'       => 'px',
			'subtitle'    => esc_html__( 'Typography option with each property can be called individually.', 'skilled-plugin' ),
			'default'     => array(
				'color'       => '#333',
				'font-style'  => '700',
				'font-family' => 'Abel',
				'google'      => true,
				'font-size'   => '33px',
				'line-height' => '40px'
			),
		),
		array(
			'id'          => 'linp-featured-courses-item-meta-typography',
			'type'        => 'typography',
			'title'       => esc_html__( 'Meta Typography', 'skilled-plugin' ),
			'google'      => true,
			'font-backup' => true,
			'text-transform' => true,
			'compiler'    => array(
				'.linp-featured-courses-carousel .sensei-course-meta',
				'.linp-featured-courses-carousel .sensei-course-meta a',
				'.linp-featured-courses-carousel .course-lesson-count',
			),
			'units'       => 'px',
			'subtitle'    => esc_html__( 'Typography option with each property can be called individually.', 'skilled-plugin' ),
			'default'     => array(
				'color'       => '#333',
				'font-style'  => '700',
				'font-family' => 'Abel',
				'google'      => true,
				'font-size'   => '15px',
				'line-height' => '20px'
			),
		),
		array(
			'id'          => 'linp-featured-courses-item-text-typography',
			'type'        => 'typography',
			'title'       => esc_html__( 'Text Typography', 'skilled-plugin' ),
			'google'      => true,
			'font-backup' => true,
			'text-transform' => true,
			'compiler'    => array(
				'.linp-featured-courses-carousel .course-excerpt',
				'.linp-featured-courses-carousel .post-ratings',
				'.owl-theme .owl-controls .owl-buttons div',
				'.owl-theme .owl-controls .owl-page span',
			),
			'units'       => 'px',
			'subtitle'    => esc_html__( 'Typography option with each property can be called individually.', 'skilled-plugin' ),
			'default'     => array(
				'color'       => '#333',
				'font-style'  => '700',
				'font-family' => 'Abel',
				'google'      => true,
				'font-size'   => '15px',
				'line-height' => '20px'
			),
		),
		array(
			'id'          => 'linp-featured-courses-item-price-regular-typography',
			'type'        => 'typography',
			'title'       => esc_html__( 'Regular Price Typography', 'skilled-plugin' ),
			'google'      => true,
			'font-backup' => true,
			'compiler'    => array(
				'.linp-featured-courses-carousel .owl-item .course-price .amount',
				'.linp-featured-courses-carousel .owl-item .course-price del .amount',
				'.wh-course-list-item .img-container .course-price .amount',
			),
			'units'       => 'px',
			'subtitle'    => esc_html__( 'Typography option with each property can be called individually.', 'skilled-plugin' ),
			'default'     => array(),
		),
		array(
			'id'       => 'linp-featured-courses-item-border-color',
			'type'     => 'color',
			'compiler' => 'true',
		    'title'    => esc_html__('Border Color', 'skilled-plugin'),
		    'default'  => '#E4E4E4',
		    'validate' => 'color',
		),
		array(
			'id'       => 'linp-featured-courses-item-wrapper-bg-color-inner',
			'type'     => 'color',
			'mode'     => 'background-color',
			'title'    => esc_html__( 'Inner Wrapper Background Color', 'skilled-plugin' ),
			'compiler' => array(
				'.linp-featured-courses-carousel .owl-item .item-inner-wrap',
				'.owl-theme .owl-controls .owl-buttons div',
				'.owl-theme .owl-controls .owl-page span',
			),
			'default'  => '',
			'validate' => 'color',
		),
		array(
			'id'       => 'linp-featured-courses-item-price-bg-color',
			'type'     => 'color',
			'mode'     => 'background-color',
			'title'    => esc_html__( 'Price Wrapper Background Color', 'skilled-plugin' ),
			'compiler' => array(
				'.linp-featured-courses-carousel .owl-item .course-price',
				'.wh-course-list-item .img-container .course-price',
			),
			'default'  => '',
			'validate' => 'color',
		),
		array(
			'id'       => 'linp-featured-courses-item-ribbon-back-bg-color',
			'type'     => 'color',
			'compiler' => 'true',
		    'title'    => esc_html__('Ribbon Back Background Color', 'skilled-plugin'),
		    'default'  => '#333',
		    'validate' => 'color',
		),
		array(
			'id'       => 'linp-featured-courses-ratings-color',
			'type'     => 'link_color',
			'title'    => esc_html__( 'Rating Color', 'skilled-plugin' ),
			'compiler' => array(
				'.linp-featured-courses-carousel .star-rating',
			),
			'visited'  => false,
			'active'   => false,
			'default'  => array(
				'regular' => '#1e73be',
				'hover'   => '#dd3333',
			)
		),
		array(
			'id'      => 'linp-featured-courses-item-img-is-rounded',
			'type'    => 'switch',
			'title'   => esc_html__( 'Image is rounded?', 'skilled-plugin' ),
			'default' => false,
			'on'      => 'Yes',
			'off'     => 'No',
		),

	)
);
