<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Post_List {

	protected $namespace = 'linp_post_list';

	function __construct() {
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ) );
		add_action( "scp_load_styles_{$this->namespace}", array( $this, 'load_css' ) );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
	}

	public function integrateWithVC() {
		global $_wp_additional_image_sizes;
		$thumbnail_sizes = array();
		foreach ( $_wp_additional_image_sizes as $name => $settings ) {
			$thumbnail_sizes[ $name . ' (' . $settings['width'] . 'x' . $settings['height'] . ')' ] = $name;
		}

		$args       = array(
			'orderby' => 'name',
			'parent'  => 0
		);
		$categories = get_categories( $args );
		$cats       = array('All' => '');
		foreach ( $categories as $category ) {

			$cats[ $category->name ] = $category->term_id;
		}

		vc_map( array(
			'name'        => esc_html__( 'Post List', 'skilled-plugin' ),
			'description' => esc_html__( '', 'skilled-plugin' ),
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'skilled-plugin' ),
			'params'      => array(
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Category', 'skilled-plugin' ),
					'param_name' => 'category',
					'value'      => $cats,
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Number of Posts', 'skilled-plugin' ),
					'param_name' => 'number_of_posts',
					'value'      => '2',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Post Date Format', 'skilled-plugin' ),
					'param_name' => 'post_date_format',
					'value'      => 'M d, Y',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Post description word length', 'skilled-plugin' ),
					'param_name'  => 'description_word_length',
					'description' => esc_html__( 'Enter number only.', 'skilled-plugin' ),
					'value'       => '15'
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Category Link Text', 'skilled-plugin' ),
					'param_name'  => 'cat_link_text',
					'value'       => 'View All',
					'description' => esc_html__( 'If you do not wish to display the Category Link just leave this field blank.', 'skilled-plugin' ),
				),
				array(
					'type'       => 'dropdown',
					'class'      => '',
					'heading'    => esc_html__( 'Layout', 'skilled-plugin' ),
					'param_name' => 'layout',
					'value'      => array(
						'Horizontal' => 'horizontal',
						'Vertical'   => 'vertical',
					),
				),
				array(
					'type'       => 'dropdown',
					'class'      => '',
					'heading'    => esc_html__( 'Number of columns', 'skilled-plugin' ),
					'param_name' => 'number_of_rows',
					'value'      => array(
						'1' => '1',
						'2' => '2',
						'3' => '3',
						'4' => '4',
						'5' => '5',
						'6' => '6',
					),
				),
				array(
					'type'       => 'dropdown',
					'class'      => '',
					'heading'    => esc_html__( 'Show Comment Count?', 'skilled-plugin' ),
					'param_name' => 'show_comment_count',
					'value'      => array(
						'Yes' => '1',
						'No'  => '0',
					),
				),
				array(
					'type'       => 'dropdown',
					'class'      => '',
					'heading'    => esc_html__( 'Thumbnail Dimensions', 'skilled-plugin' ),
					'param_name' => 'thumbnail_dimensions',
					'value'      => $thumbnail_sizes,
				),
                array(
					'type'       => 'colorpicker',
					'class'      => '',
					'heading'    => esc_html__( 'Meta Data Color', 'skilled-plugin' ),
					'param_name' => 'meta_data_color',
					'value'      => '',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
				),
			)
		) );
	}

	public function load_css( $atts ) {

		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'meta_data_color' => '',
		), $atts ) );


		$style = '';

		if ( $meta_data_color ) {
            $style .= ".{$uid} .meta-data {color:{$meta_data_color}}";
        }
		
		if ( $style ) {
			wp_add_inline_style( 'skilled_options_style', $style );
		}
	}

	public function render( $atts, $content = null ) {

		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'category'                => null,
			'number_of_posts'         => 2,
			'cat_link_text'           => '',
			'layout'                  => 'horizontal',
			'number_of_rows'          => 1,
			'description_word_length' => '15',
			'thumbnail_dimensions'    => 'thumbnail',
			'post_date_format'        => 'Y-m-d',
			'show_comment_count'      => '1',
			'meta_data_color'         => '',
			'el_class'                => '',
		), $atts ) );

		// $content = wpb_js_remove_wpautop($content); // fix unclosed/unwanted paragraph tags in $content

		$args = array(
			'numberposts'      => $number_of_posts,
			'orderby'          => 'post_date',
			'order'            => 'DESC',
			'suppress_filters' => false,
		);

		if ($category) {
			$args['category'] = $category;
		}

		$posts = get_posts( $args );


		// If no posts let's bail
		if ( ! $posts ) {
			return;
		}

		$grid = array(
			'one whole',
			'one half',
			'one third',
			'one fourth',
			'one fifth',
			'one sixth',
		);


		$grid_class = $grid[ (int) $number_of_rows - 1 ];

		ob_start();

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'linp-post-list ' . $el_class, $this->namespace, $atts );
		$css_class .= ' ' . $uid;
		?>
		<div class="<?php echo esc_attr( $css_class ); ?> <?php echo esc_attr( $layout ); ?>">
			<?php foreach ( array_chunk( $posts, $number_of_rows ) as $chunk ): ?>
				<div class="vc_row">
					<?php foreach ( $chunk as $post ): ?>
						<?php if ( $layout == 'vertical' ) : ?>
							<?php include 'templates/vertical.php'; ?>
						<?php else: ?>
							<?php include 'templates/horizontal.php'; ?>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
			<?php if ( $cat_link_text ): ?>
				<?php $category_link = get_category_link( $category ); ?>
				<a class="cbp_widget_link cbp_widget_button" href="<?php echo esc_url( $category_link ); ?>"><?php echo esc_html( $cat_link_text ); ?></a>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

}

new Skilled_Plugin_VC_Addon_Post_List();
