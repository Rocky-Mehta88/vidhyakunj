<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}


class Skilled_Plugin_VC_Addon_Sensei_Courses_Carousel {

	protected $namespace = 'linp_sensei_courses_carousel';

	function __construct() {
		// We safely integrate with VC with this hook
		// needs 100 so Sensei taxonomy is intialized
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ), 100 );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
	}

	public function integrateWithVC() {
		global $_wp_additional_image_sizes;
		$thumbs_dimensions_array = array( 'thumbnail' );

		if ( $_wp_additional_image_sizes ) {
			foreach ( $_wp_additional_image_sizes as $imageSizeName => $image_size ) {
				$thumbs_dimensions_array[ $imageSizeName . ' | ' . $image_size['width'] . 'px, ' . $image_size['height'] . 'px' ] = $imageSizeName;
			}
		}
		$thumbs_dimensions_array[] = 'full-width';


		$args = array(
			'taxonomy' => 'course-category',
		);

		$project_categories = get_categories( $args );

		$project_category_arr                    = array();
		$project_category_arr['Select Category'] = '';
		foreach ( $project_categories as $project_category ) {
			if ( is_object( $project_category ) && $project_category->term_id ) {
				$project_category_arr[ $project_category->name ] = $project_category->term_id;
			}
		}

		vc_map( array(
			'name'        => esc_html__( 'Sensei - Courses Carousel', 'skilled-plugin' ),
			'description' => esc_html__( 'Display courses', 'skilled-plugin' ),
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'skilled-plugin' ),
			'params'      => array(
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__( 'Title', 'skilled-plugin' ),
					'param_name'  => 'title',
					'value'       => '',
					'description' => esc_html__( 'Title to display on front.', 'skilled-plugin' )
				),
				array(
					'type'        => 'dropdown',
					'holder'      => '',
					'class'       => '',
					'admin_label' => true,
					'heading'     => esc_html__( 'Category', 'skilled-plugin' ),
					'param_name'  => 'category_id',
					'value'       => $project_category_arr,
					'description' => esc_html__( 'If category is selected Course Type will be disregarded.', 'skilled-plugin' ),
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Course Type', 'skilled-plugin' ),
					'param_name' => 'course_type',
					'value'      => array(
						'All'              => 'usercourses',
						'Free Courses'     => 'freecourses',
						'Paid Courses'     => 'paidcourses',
						'Featured Courses' => 'featuredcourses',
					),
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Image Size', 'skilled-plugin' ),
					'param_name' => 'image_size',
					'value'      => $thumbs_dimensions_array,
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Show Ratings?', 'skilled-plugin' ),
					'param_name' => 'show_ratings',
					'value'      => array(
						'Yes' => '1',
						'No'  => '0',
					),
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Show Separator?', 'skilled-plugin' ),
					'param_name' => 'show_separator',
					'value'      => array(
						'Yes' => '1',
						'No'  => '0',
					),
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Show Category?', 'skilled-plugin' ),
					'param_name' => 'show_category',
					'value'      => array(
						'Yes' => '1',
						'No'  => '0',
					),
				),
				array(
					'type'        => 'dropdown',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Image takes the full width', 'skilled-plugin' ),
					'description' => esc_html__( 'Inner padding won\'t affect the image', 'skilled-plugin' ),
					'param_name'  => 'image_is_full_width',
					'value'       => array(
						'Yes' => '1',
						'No'  => '0',
					),
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Image is rounded?', 'skilled-plugin' ),
					'param_name' => 'image_is_rounded',
					'value'      => array(
						'No'  => '0',
						'Yes' => '1',
					),
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Show Excerpt?', 'skilled-plugin' ),
					'param_name' => 'show_excerpt',
					'value'      => array(
						'Yes' => '1',
						'No'  => '0',
					),
				),
				array(
					'type'        => 'textfield',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Number of Words', 'skilled-plugin' ),
					'param_name'  => 'number_of_words',
					'value'       => '10',
					'description' => esc_html__( 'Number of words of the excerpt.', 'skilled-plugin' ),
					'group'       => '',
				),
				array(
					'type'        => 'textfield',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Number of Items', 'skilled-plugin' ),
					'param_name'  => 'number_of_items',
					'value'       => '8',
					'description' => esc_html__( 'Number of items to show.', 'skilled-plugin' ),
					'group'       => 'Slider Settings',
				),
				array(
					'type'        => 'textfield',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Number of Items per Slide', 'skilled-plugin' ),
					'param_name'  => 'number_of_items_per_slide',
					'value'       => '4',
					'description' => esc_html__( 'Number of items per slide.', 'skilled-plugin' ),
					'group'       => 'Slider Settings',
				),
				array(
					'type'       => 'textfield',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Slide Speed', 'skilled-plugin' ),
					'param_name' => 'slide_speed',
					'value'      => '500',
					'group'      => 'Slider Settings',
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Auto Play', 'skilled-plugin' ),
					'param_name' => 'autoplay',
					'value'      => array(
						'No'  => '0',
						'Yes' => '1',
					),
					'group'      => 'Slider Settings',
				),
				array(
					'type'       => 'dropdown',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Show Bullets', 'skilled-plugin' ),
					'param_name' => 'show_bullets',
					'value'      => array(
						'No'  => '0',
						'Yes' => '1',
					),
					'group'      => 'Slider Settings',
				),
				array(
					'type'        => 'dropdown',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Adaptive Height', 'skilled-plugin' ),
					'param_name'  => 'adaptive_height',
					'description' => 'Use it only for one item per page setting.',
					'value'       => array(
						'No'  => '0',
						'Yes' => '1',
					),
					'group'       => 'Slider Settings',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
				),
			)
		) );
	}

	public function render( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'title'                     => '',
			'category_id'               => null,
			'course_type'               => 'usercourses',
			'includes'                  => '',
			'number_of_items'           => '8',
			'number_of_items_per_slide' => '4',
			'slide_speed'               => '500',
			'autoplay'                  => '0',
			// 'show_navigation'           => '1',
			// 'controls_position'         => 'bottom-center',
			'show_bullets'              => '0',
			'show_ratings'              => '1',
			'show_separator'            => '1',
			'show_category'             => '1',
			'image_is_full_width'       => '1',
			'image_is_rounded'          => '0',
			// 'show_avatar'               => '1',
			'show_excerpt'              => '1',
			'number_of_words'           => '10',
			'adaptive_height'           => 'true',
			'image_size'                => 'thumbnail',
			'el_class'                  => '',
		), $atts ) );


		if ( class_exists( 'WooThemes_Sensei' ) ) {

			

			// adapted from woothemes-sensei/inc/woothemes-sensei-template.php shortcode_featured_courses()
			global $woothemes_sensei, $post, $wp_query, $current_user;

			$query_type = $course_type;

			$amount          = $number_of_items;
			$course_includes = array();
			$course_excludes = array();

			if ( $category_id ) {

				$args = array(
					'numberposts'      => - 1,
					'post_type'        => 'course',
					'post_status'      => 'publish',
					'suppress_filters' => 0
				);

				$args['tax_query'] = array(
					array(
						'taxonomy' => 'course-category',
						'field'    => 'term_id',
						'terms'    => $category_id
					)
				);

				$posts_array = get_posts( $args );
			} else {

				$posts_array = $woothemes_sensei->post_types->course->course_query( $amount, $query_type, $course_includes, $course_excludes );
			}

			$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'linp-featured-courses-carousel wh-sensei-courses-carousel' . $el_class, $this->namespace, $atts );

			ob_start();
			if ( count( $posts_array ) > 0 ) {
				?>
				<?php if ( $title ): ?>
					<h2><?php echo esc_html( $title ); ?></h2>
				<?php endif ?>
				<div class="<?php echo esc_attr( $css_class ); ?>"
					data-items="<?php echo esc_attr( (int) $number_of_items_per_slide ); ?>"
					data-slide-speed="<?php echo esc_attr( (int) $slide_speed ); ?>"
					data-auto-play="<?php echo esc_attr( (int) $autoplay ? 'true' : 'false' ); ?>"
					data-show-bullets="<?php echo esc_attr( (int) $show_bullets ? 'true' : 'false' ); ?>"
					data-auto-height="<?php echo esc_attr( (int) $adaptive_height ? 'true' : 'false' ); ?>"
				>
					<?php
					foreach ( $posts_array as $post_item ) {
						// Make sure the other loops dont include the same post twice!
						array_push( $course_excludes, $post_item->ID );
						// Get meta data
						$post_id               = absint( $post_item->ID );
						$post_title            = $post_item->post_title;
						$user_info             = get_userdata( absint( $post_item->post_author ) );
						$author_link           = get_author_posts_url( absint( $post_item->post_author ) );
						$author_display_name   = $user_info->display_name;
						$author_id             = $post_item->post_author;
						$category_output       = get_the_term_list( $post_id, 'course-category', '', ', ', '' );
						$preview_lesson_count  = intval( $woothemes_sensei->post_types->course->course_lesson_preview_count( $post_id ) );
						$is_user_taking_course = WooThemes_Sensei_Utils::user_started_course( $post_id, $current_user->ID );
						?>
						<div>
							<?php if ( $image_is_full_width ): ?>
								<?php include 'partials/image.php'; ?>
							<?php endif ?>
							<div class="item-inner-wrap">
								<?php
								if ( ! $image_is_full_width ) {
									include 'partials/image.php';
								}
								include 'partials/price.php';
								include 'partials/categories.php';
								include 'partials/title.php';
								include 'partials/excerpt.php';
								include 'partials/ratings.php';
								?>
							</div>
							<?php include 'partials/lesson-count.php'; ?>
						</div>
					<?php
					} // End For Loop
					?>
				</div>
			<?php
			}
			return ob_get_clean();
		}
	}

	public function loadCssAndJs() {
		wp_enqueue_script( 'owl.carousel', plugins_url( 'assets/owl.carousel.min.js', __FILE__ ), array( 'jquery' ), false, true );
		wp_enqueue_script( 'sensei-courses-carousel', plugins_url( 'assets/sensei-courses-carousel.js', __FILE__ ), array( 'jquery' ), false, true );
	}

}

new Skilled_Plugin_VC_Addon_Sensei_Courses_Carousel();
