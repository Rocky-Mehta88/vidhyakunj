<h3 class="course-title">
    <a href="<?php the_permalink( $post_id ); ?>" title="<?php echo esc_attr( $post_title ); ?>"><?php echo esc_html( $post_title ); ?></a>
</h3>