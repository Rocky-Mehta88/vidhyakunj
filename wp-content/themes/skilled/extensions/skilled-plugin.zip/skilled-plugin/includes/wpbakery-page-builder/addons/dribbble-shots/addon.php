<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Dribbble_Shots {

	protected $shortcode_name = 'scp_dribbble_shots';

	function __construct() {
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ) );
		add_shortcode( $this->shortcode_name, array( $this, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'loadCssAndJs' ) );
	}

	public function integrateWithVC() {
		vc_map( array(
			'name'        => esc_html__( 'Dribbble Shots', 'skilled-plugin' ),
			'description' => '',
			'base'        => $this->shortcode_name,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => 'Aislin',
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Position', 'skilled-plugin' ),
					'param_name'  => 'position',
					'value'       => array(
						'Left'   => 'vc_pull-left',
						'Right'  => 'vc_pull-right',
						'Center' => 'vc_txt_align_center',
					),
					'description' => esc_html__( 'Float.', 'skilled-plugin' )
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Token', 'skilled-plugin' ),
					'param_name'  => 'token',
					'description' => esc_html__( 'You need to generate token for Dribble app in order to use this widget.', 'skilled-plugin' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Number of Items', 'skilled-plugin' ),
					'param_name'  => 'number_of_items',
					'description' => esc_html__( 'Number of items to fetch.', 'skilled-plugin' ),
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Number of Columns', 'skilled-plugin' ),
					'param_name' => 'number_of_columns',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Shot Width', 'skilled-plugin' ),
					'param_name' => 'shot_width',
				),
				array(
					'type'       => 'textfield',
					'heading'    => esc_html__( 'Gap', 'skilled-plugin' ),
					'param_name' => 'gap',
					'description' => esc_html__( 'Gap between shots.', 'skilled-plugin' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'js_composer' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' ),
				),
				array(
					'type'       => 'css_editor',
					'heading'    => esc_html__( 'CSS box', 'js_composer' ),
					'param_name' => 'css',
					'group'      => esc_html__( 'Design Options', 'js_composer' ),
				),

			)
		) );
	}

	public function render( $atts, $content = null ) {

		extract( shortcode_atts( array(
			'token'             => '',
			'number_of_items'   => 6,
			'number_of_columns' => 3,
			'shot_width'        => '',
			'gap'               => 15,
			'position'          => 'vc_pull-left',
			'css'               => '',
			'el_class'          => '',
		), $atts ) );

		if ( ! $token ) {
			return;
		}

		$class_to_filter = 'dribble-shots ' . $position;
		$class_to_filter .= vc_shortcode_custom_css_class( $css, ' ' );
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter . ' ' . $el_class, $this->shortcode_name, $atts );

		$settings = json_encode( array(
			'token'             => $token,
			// 'token'             => 'f688ac519289f19ce5cebc1383c15ad5c02bd58205cd83c86cbb0ce09170c1b4',
			'number_of_items'   => $number_of_items,
			'number_of_columns' => $number_of_columns,
			'shot_width'        => skilled_plugin_sanitize_size( $shot_width ),
			'gap'               => skilled_plugin_sanitize_size( $gap ),
		) );

		// API keys need to be registered https://medium.com/@nithin_94885/dribbble-shots-in-your-website-v2-api-5945a355d106

		$inline_js = "
		jQuery(function ($) {
			var settings = {$settings};
			jribbble.setToken(settings.token);

			jribbble.shots({per_page: settings.number_of_items}, function (shots) {
				var html = [];
				var style = '';
				if (settings.shot_width) {
					style += 'width:' + settings.shot_width + ';';
				}
				if (settings.gap) {
					style += 'padding-right:' + settings.gap + ';';
					style += 'padding-bottom:' + settings.gap + ';';
				}
				shots.forEach(function (shot, i) {
					var itemStyle = style;

					itemStyle = 'style=\"' + itemStyle + '\"';

					html.push('<li class=\"dribble-shots--shot\"' + itemStyle + '>');
					html.push('<a href=\"' + shot.html_url + '\" target=\"_blank\">');
					html.push('<img src=\"' + shot.images.normal + '\">');
					html.push('</a></li>');
				});
				$('.dribble-shots').html(html.join(''));
			});
		});
		";

		wp_enqueue_script( 'jribbble' );
		wp_add_inline_script( 'jribbble', $inline_js );

		ob_start();
		?>
		<ul class="<?php echo esc_attr( $css_class ); ?>"></ul>
		<?php
		return ob_get_clean();
	}

	public function loadCssAndJs() {
		wp_register_script( 'jribbble', plugins_url( 'assets/jribbble.min.js', __FILE__ ), array( 'jquery' ) );
	}
}

new Skilled_Plugin_VC_Addon_Dribbble_Shots();
