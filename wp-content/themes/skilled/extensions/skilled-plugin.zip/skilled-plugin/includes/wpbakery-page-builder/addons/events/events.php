<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Events {

	protected $namespace = 'linp_events';

	function __construct() {
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ) );
		add_action( "scp_load_styles_{$this->namespace}", array( $this, 'load_css' ) );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
	}

	public function integrateWithVC() {

		vc_map( array(
			'name'        => esc_html__( 'Tribe Events', 'skilled-plugin' ),
			'description' => '',
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'js_composer' ),
			'params'      => array(
				array(
					'type'        => 'textfield',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Start Date Format', 'skilled-plugin' ),
					'param_name'  => 'start_date_format',
					'admin_label' => true,
					'value'       => 'M d, Y',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Nubmer of events to display', 'skilled-plugin' ),
					'param_name'  => 'limit',
					'description' => esc_html__( 'Enter number only.', 'skilled-plugin' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Event description word length', 'skilled-plugin' ),
					'param_name'  => 'description_word_length',
					'description' => esc_html__( 'Enter number only.', 'skilled-plugin' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'View All Events Link Text', 'skilled-plugin' ),
					'param_name'  => 'view_all_events_link_text',
					'description' => esc_html__( 'If Left Blank link will not show.', 'skilled-plugin' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
				),
				/**
				 *  Title Typography
				 */
				array(
					"type"             => "ult_param_heading",
					"text"             => esc_html__( "Title", 'skilled-plugin' ),
					"param_name"       => "main_heading_typograpy",
					"group"            => "Typography",
					"class"            => "ult-param-heading",
					'edit_field_class' => 'ult-param-heading-wrapper no-top-margin vc_column vc_col-sm-12',
				),
				array(
					"type"       => "textfield",
					"class"      => "font-size",
					"heading"    => esc_html__( "Font size", 'ultimate_vc' ),
					"param_name" => "main_heading_font_size",
					"group"      => "Typography"
				),
				array(
					"type"       => "colorpicker",
					"class"      => "",
					"heading"    => esc_html__( "Font Color", 'skilled-plugin' ),
					"param_name" => "main_heading_color",
					"value"      => "",
					"group"      => "Typography"
				),
				array(
					"type"       => "textfield",
					"class"      => "font-size",
					"heading"    => esc_html__( "Line Height", 'ultimate_vc' ),
					"param_name" => "main_heading_line_height",
					"group"      => "Typography"
				),
				/**
				 * Text
				 */
				array(
					"type"             => "ult_param_heading",
					"text"             => esc_html__( "Sub Heading Settings", 'skilled-plugin' ),
					"param_name"       => "sub_heading_typograpy",
					"group"            => "Typography",
					"class"            => "ult-param-heading",
					'edit_field_class' => 'ult-param-heading-wrapper vc_column vc_col-sm-12',
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Font Size", 'ultimate_vc' ),
					"param_name" => "sub_heading_font_size",
					"group"      => "Typography"
				),
				array(
					"type"       => "colorpicker",
					"class"      => "",
					"heading"    => esc_html__( "Font Color", 'skilled-plugin' ),
					"param_name" => "sub_heading_color",
					"value"      => "",
					"group"      => "Typography",
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Line Height", 'skilled-plugin' ),
					"param_name" => "sub_heading_line_height",
					"group"      => "Typography"
				),
				/**
				 * Date
				 */
				array(
					"type"             => "ult_param_heading",
					"text"             => esc_html__( "Date Settings", 'skilled-plugin' ),
					"param_name"       => "date_heading_typograpy",
					"group"            => "Typography",
					"class"            => "ult-param-heading",
					'edit_field_class' => 'ult-param-heading-wrapper vc_column vc_col-sm-12',
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Font Size", 'ultimate_vc' ),
					"param_name" => "date_heading_font_size",
					"group"      => "Typography"
				),
				array(
					"type"       => "colorpicker",
					"class"      => "",
					"heading"    => esc_html__( "Font Color", 'skilled-plugin' ),
					"param_name" => "date_heading_color",
					"value"      => "",
					"group"      => "Typography",
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Line Height", 'skilled-plugin' ),
					"param_name" => "date_heading_line_height",
					"group"      => "Typography"
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Padding Top", 'skilled-plugin' ),
					"param_name" => "date_heading_padding_top",
					"group"      => "Typography"
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Width", 'skilled-plugin' ),
					"param_name" => "date_heading_width",
					"group"      => "Typography"
				),
				/**
				 * Circles
				 */
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Circle Width", 'skilled-plugin' ),
					"param_name" => "circle_width",
					"group"      => "Circles",
					'value'      => '',
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Circle Margin Right", 'skilled-plugin' ),
					"param_name" => "circle_margin_right",
					"group"      => "Circles",
					'value'      => '',
				),
				array(
					"type"       => "colorpicker",
					"class"      => "",
					"heading"    => esc_html__( "Border Color", 'skilled-plugin' ),
					"param_name" => "circle_border_color",
					"value"      => "",
					"group"      => "Circles",
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Border Width", 'skilled-plugin' ),
					"param_name" => "circle_border_width",
					"group"      => "Circles"
				),
				array(
					"type"       => "colorpicker",
					"class"      => "",
					"heading"    => esc_html__( "Background Color", 'skilled-plugin' ),
					"param_name" => "circle_background_color",
					"group"      => "Circles"
				),
				// inner circle
				array(
					"type"       => "colorpicker",
					"class"      => "",
					"heading"    => esc_html__( "Inner Circle Background Color", 'skilled-plugin' ),
					"param_name" => "inner_circle_background_color",
					"group"      => "Circles"
				),
				array(
					"type"       => "textfield",
					"class"      => "",
					"heading"    => esc_html__( "Circle Gap", 'skilled-plugin' ),
					"param_name" => "circle_gap",
					"group"      => "Circles"
				),
			)
		) );
	}

	public function load_css($atts) {
		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			// title
			'main_heading_font_size'        => '',
			'main_heading_line_height'      => '',
			'main_heading_color'            => '',
			'main_heading_margin'           => '',
			// text
			'sub_heading_font_size'         => '',
			'sub_heading_line_height'       => '',
			'sub_heading_style'             => '',
			'sub_heading_color'             => '',
			'sub_heading_margin'            => '',
			// date
			'date_heading_font_size'        => '',
			'date_heading_line_height'      => '',
			'date_heading_style'            => '',
			'date_heading_color'            => '',
			'date_heading_margin'           => '',
			'date_heading_padding_top'      => '',
			'date_heading_width'            => '50',
			// circles
			'circle_width'                  => '85',
			'circle_margin_right'           => '10',
			'circle_border_color'           => '',
			'circle_border_width'           => '',
			'circle_background_color'       => '',
			// inner circle
			'inner_circle_background_color' => '',
			'circle_gap'                    => '',
		), $atts ) );

		$style = '';
		$main_heading_style = array();
		$sub_heading_style = array();
		$date_heading_style = array();
		$outer_circle_style = array();

		/**
		 * Title
		 */
		if ( $main_heading_color != '' ) {
			$main_heading_style[] = "color:{$main_heading_color}";
		}
		if ( $main_heading_margin != '' ) {
			$main_heading_style[] = $main_heading_margin;
		}
		if ( $main_heading_font_size != '' ) {
			$main_heading_style[] = 'font-size:' . (int) $main_heading_font_size . 'px';
		}
		if ( $main_heading_line_height != '' ) {
			$main_heading_style[] = 'line-height:' . (int) $main_heading_line_height . 'px';
		}
		if ( ! empty( $main_heading_style ) ) {
			$main_heading_style = implode(';', $main_heading_style);
			$style .= ".{$uid} .title a{{$main_heading_style}}";
		}

		/**
		 * Subheading 
		 */
		if ( $sub_heading_color != '' ) {
			$sub_heading_style[] = "color:{$sub_heading_color}";
		}
		if ( $sub_heading_font_size != '' ) {
			$sub_heading_style[] = 'font-size:' . (int) $sub_heading_font_size . 'px';
		}
		if ( $sub_heading_line_height != '' ) {
			$sub_heading_style[] = 'line-height:' . (int) $sub_heading_line_height . 'px';
		}
		if ( ! empty( $main_heading_style ) ) {
			$sub_heading_style = implode(';', $sub_heading_style);
			$style .= ".{$uid} .content{{$sub_heading_style}}";
		}

		/**
		 *  Date
		 */
		if ( $date_heading_color != '' ) {
			$date_heading_style[] = "color:{$date_heading_color}";
		}
		if ( $date_heading_font_size != '' ) {
			$date_heading_style[] = 'font-size:' . (int) $date_heading_font_size . 'px';
		}
		if ( $date_heading_line_height != '' ) {
			$date_heading_style[] = 'line-height:' . (int) $date_heading_line_height . 'px';
		}
		if ( $date_heading_padding_top != '' ) {
			$date_heading_style[] = 'padding-top:' . (int) $date_heading_padding_top . 'px';
		}
		if ( $date_heading_width != '' ) {
			$date_heading_style[] = 'width:' . (int) $date_heading_width . 'px';
		}
		if ( ! empty( $date_heading_style ) ) {
			$date_heading_style = implode(';', $date_heading_style);
			$style .= ".{$uid} .date{{$date_heading_style}}";
		}

		/**
		 * Outer Circle
		 */
		if ( $circle_width != '' ) {
			$outer_circle_style[] = 'width:' . (int) $circle_width . 'px';
			$outer_circle_style[] = 'height:' . (int) $circle_width . 'px';
		}
		if ( $circle_background_color != '' ) {
			$outer_circle_style[] = "background-color:{$circle_background_color}";
		}
		if ( $circle_gap != '' ) {
			$outer_circle_style[] = 'padding:' . (int) $circle_gap . 'px';
		}
		if ( $circle_border_color != '' && $circle_border_width ) {

			$circle_border_width = (int) $circle_border_width . 'px';

			$outer_circle_style[] = "border:{$circle_border_width} solid {$circle_border_color}";
		}
		if ( ! empty( $outer_circle_style ) ) {
			$outer_circle_style = implode(';', $outer_circle_style);
			$style .= ".{$uid} .event .icon{{$outer_circle_style}}";
		}

		/**
		 * Inner Circle
		 */
		if ( $inner_circle_background_color != '' ) {
			$style .= ".{$uid} .inner-circle{background-color:{$inner_circle_background_color}}";
		}

		/**
		 * Info
		 */
		if ( $circle_width ) {
			$margin = (int) $circle_width;
			if ( $circle_margin_right != '' ) {
				$margin += (int) $circle_margin_right;
			}
			$style.= ".{$uid} .info{margin-left:{$margin}px}";
		}

		if ( $style ) {
			wp_add_inline_style( 'skilled_options_style', $style );
		}
	}

	public function render( $atts, $content = null ) {
		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'title'                         => '',
			'limit'                         => '3',
			'description_word_length'       => '20',
			'start_date_format'             => 'M d, Y',
			'textarea_html'                 => '',
			'el_class'                      => '',
			'main_heading'                  => '',
			'sub_heading'                   => '',
			'date_heading'                  => '',
		), $atts ) );

		ob_start();

		if ( ! function_exists( 'tribe_get_events' ) ) {
			return;
		}

		$posts = tribe_get_events( apply_filters( 'tribe_events_list_widget_query_args', array(
			'eventDisplay'   => 'list',
			'posts_per_page' => $limit
		) ) );

		if ( ! $posts ) {
			echo '<p>' . esc_html__( 'There are no upcoming events at this time.', 'skilled-plugin' ) . '</p>';
			return;
		}

		?>
		<div class="linp-tribe-events-wrap">
			<ul class="linp-tribe-events <?php echo esc_attr( $uid ); ?>">
				<?php
				foreach ( $posts as $post ) :
					setup_postdata( $post );
					?>
					<li class="event">
						<div class="icon">
							<div class="inner-circle">
								<div class="date">
									<?php echo tribe_get_start_date( $post, false, $start_date_format ); ?>
								</div>
							</div>
						</div>
						<div class="info">
							<div class="title">
								<a href="<?php echo esc_url( tribe_get_event_link( $post ) ); ?>" 
								rel="bookmark"><?php echo esc_html( $post->post_title ); ?></a>
							</div>

							<div class="content">
								<?php echo wp_kses_post( wp_trim_words( strip_shortcodes( $post->post_content ), $description_word_length, '&hellip;' ) ); ?>
							</div>
						</div>
					</li>
				<?php
				endforeach;
				?>
			</ul>
			<?php if ( ! empty( $view_all_events_link_text ) ) : ?>
				<p class="linp-tribe-events-link">
					<a href="<?php echo esc_url( tribe_get_events_link() ); ?>" rel="bookmark"><?php echo esc_html( $view_all_events_link_text ); ?></a>
				</p>
			<?php endif; ?>
		</div>	
		<?php
		wp_reset_query();
		return ob_get_clean();
	}

}

new Skilled_Plugin_VC_Addon_Events();
