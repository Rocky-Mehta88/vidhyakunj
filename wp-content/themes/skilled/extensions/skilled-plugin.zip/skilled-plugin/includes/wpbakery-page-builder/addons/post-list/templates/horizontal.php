<div class="wh-padding item <?php echo esc_attr( $grid_class ); ?>">

	<?php $img_url = ''; ?>
	<?php if ( has_post_thumbnail( $post->ID ) ) : ?>
		<?php $img_url = get_the_post_thumbnail( $post->ID, $thumbnail_dimensions, array( 'class' => 'post-list-thumb' ) ); ?>
	<?php endif; ?>
	<?php if ( '' != $img_url ) : ?>
		<div class="img-container">
			<a href="<?php the_permalink( $post->ID ) ?>"
			   title="<?php echo esc_attr( get_post_field( 'post_title', $post->ID ) ); ?>"><?php echo wp_kses_post( $img_url ); ?></a>
		</div>
	<?php endif; ?>
	<div class="data">

		<h6><a title="<?php echo esc_attr( $post->post_title ); ?>"
		       href="<?php the_permalink( $post->ID ); ?>"><?php echo esc_html( $post->post_title ); ?></a></h6>

		<div class="content">
			<?php $text = apply_filters( 'widget_text', strip_shortcodes( $post->post_content ) ); ?>
			<p><?php echo wp_kses_post( wp_trim_words( strip_shortcodes( $text ), $description_word_length, '&hellip;' ) ); ?></p>
		</div>

		<hr/>

			<div class="meta-data">
                <span class="date">
                    <?php echo wp_kses_post( date_i18n( $post_date_format, strtotime( $post->post_date ) ) ); ?>
                </span>
			<?php if ( (int) $show_comment_count ): ?>
				<span class="comments">
                    <i class="lnr lnr-bubble"></i> (<?php echo esc_html( $post->comment_count ); ?>)
                </span>
			<?php endif; ?>
			<span class="author">
                <?php esc_html_e( 'by', 'skilled-plugin' ); ?> <a
					href="<?php echo esc_url( get_author_posts_url( $post->post_author ) ); ?>">
					<?php the_author_meta( 'display_name', $post->post_author ); ?>
				</a>
            </span>

		</div>
	</div>
</div>