<?php $course_price = function_exists( 'skilled_sensei_simple_course_price' ) ? skilled_sensei_simple_course_price( $post_id ) : false; ?>
<?php if ( $course_price ): ?>
	<div class="price">
		<?php echo wp_kses_post( $course_price ); ?>
	</div>
<?php endif; ?>
