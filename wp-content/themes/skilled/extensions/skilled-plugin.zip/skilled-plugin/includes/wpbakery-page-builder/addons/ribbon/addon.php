<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Ribbon {

	protected $namespace = 'scp_ribbon';

	function __construct() {
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ) );
		add_action( "scp_load_styles_{$this->namespace}", array( $this, 'load_css' ) );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
	}

	public function integrateWithVC() {
		vc_map( array(
			'name'        => esc_html__( 'Ribbon', 'skilled-plugin' ),
			'description' => '',
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'js_composer' ),
			'params'      => array(
				array(
					'type'        => 'colorpicker',
					'heading'     => esc_html__( 'Background Color', 'js_composer' ),
					'param_name'  => 'ribbon_bg_color',
					'save_always' => 'true',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Ribbon Depth', 'skilled-plugin' ),
					'description' => esc_html__( 'Enter value in px.', 'skilled-plugin' ),
					'param_name'  => 'ribbon_depth',
					'save_always' => 'true',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Ribbon Height', 'skilled-plugin' ),
					'description' => esc_html__( 'Enter value in px.', 'skilled-plugin' ),
					'param_name'  => 'height',
					'save_always' => 'true',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'class'       => '',
					'heading'     => esc_html__( 'Title', 'skilled-plugin' ),
					'param_name'  => 'title',
					'value'       => esc_html__( 'Title', 'skilled-plugin' ),
					'description' => esc_html__( 'Widget title.', 'skilled-plugin' ),
					'save_always' => 'true',
					'group'       => esc_html__( 'Text Settings', 'js_composer' ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
					'save_always' => 'true',
				),
				array(
					'type'        => 'css_editor',
					'heading'     => esc_html__( 'CSS box', 'js_composer' ),
					'param_name'  => 'css',
					'group'       => esc_html__( 'Design Options', 'js_composer' ),
					'save_always' => 'true',
				)
			)
		) );
	}

	public function load_css( $atts ) {

		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'ribbon_bg_color' => '#999',
			'height'          => '50px',
			'ribbon_depth'    => '50px',
		), $atts ) );

		$style = '';


		$ribbon_depth = (int) $ribbon_depth . 'px';
		$half_height  = (int) $height / 2 . 'px';

		/**
		 * Ribbon style
		 */
		$ribbon_style = array(
			'width:100%',
			'height:100%',
			"border-width:{$half_height} {$ribbon_depth}",
			'border-style: solid',
			"border-color:{$ribbon_bg_color} rgba(0, 0, 0, 0) {$ribbon_bg_color} rgba(0, 0, 0, 0)",
			'position: absolute',
			'top: 0',
			'left: 0',
		);
		$ribbon_style = implode(';', $ribbon_style);
		$style .= ".{$uid} .scp-shortcode-ribbon{{$ribbon_style}}";


		/**
		 * Wrapper style
		 */
		$wrapper_style = array(
			'width:100%',
			'text-align:center',
			'padding:16px',
			'font-weight:bold',
			'text-transform:uppercase',
			"height:{$height}",
		);
		$wrapper_style = implode(';', $wrapper_style);
		$style .= ".{$uid}{{$wrapper_style}}";

		if ( $style ) {
			wp_add_inline_style( 'skilled_options_style', $style );
		}
	}

	public function render( $atts, $content = null ) {

		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'title'           => 'The Title',
			'ribbon_bg_color' => '#999',
			'height'          => '50px',
			'ribbon_depth'    => '50px',
			'el_class'        => '',
			'css'             => '',
		), $atts ) );

		ob_start();
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'scp-ribbon-wrapper ' . $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->namespace, $atts );
		$css_class .= ' ' . $uid;
		?>
		<div class="<?php echo esc_attr( $css_class ); ?>">
			<div class="scp-shortcode-ribbon"></div>
			<div class="scp-ribbon-text">
				<?php echo esc_html( $title ); ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

}

new Skilled_Plugin_VC_Addon_Ribbon();
