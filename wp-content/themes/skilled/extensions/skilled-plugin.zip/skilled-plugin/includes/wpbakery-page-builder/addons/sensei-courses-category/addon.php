<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Skilled_Plugin_VC_Addon_Sensei_Courses_Category {

	protected $namespace = 'dntp_sensei_courses_category';

	function __construct() {
		// We safely integrate with VC with this hook
		add_action( vc_is_inline() ? 'init' : 'admin_init', array( $this, 'integrateWithVC' ), 110 );
		add_action( "scp_load_styles_{$this->namespace}", array( $this, 'load_css' ) );
		add_shortcode( $this->namespace, array( $this, 'render' ) );
	}

	public function integrateWithVC() {

		$args = array(
			'taxonomy' => 'course-category',
		);

		$course_categories = get_categories( $args );

		$course_category_arr                    = array();
		$course_category_arr['Select Category'] = '';
		$course_category_arr['All']             = 0;
		foreach ( $course_categories as $course_category ) {
			if ( is_object( $course_category ) && $course_category->term_id ) {
				$course_category_arr[ $course_category->name . ' (cat ID = ' . $course_category->term_id . ')' ] = $course_category->term_id;
			}
		}

		vc_map( array(
			'name'        => esc_html__( 'Courses Category', 'skilled-plugin' ),
			'description' => '',
			'base'        => $this->namespace,
			'class'       => '',
			'controls'    => 'full',
			'icon'        => plugins_url( 'assets/aislin-vc-icon.png', __FILE__ ),
			'category'    => esc_html__( 'Aislin', 'js_composer' ),
			'params'      => array(
				array(
					'type'       => 'textfield',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Top Title', 'skilled-plugin' ),
					'param_name' => 'top_title',
					'value'      => esc_html__( 'Top Title', 'skilled-plugin' ),
				),
				array(
					'type'       => 'textfield',
					'holder'     => '',
					'class'      => '',
					'heading'    => esc_html__( 'Title', 'skilled-plugin' ),
					'param_name' => 'title',
					'value'      => esc_html__( 'The Title', 'skilled-plugin' ),
				),
				array(
					'type'        => 'dropdown',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Use Categories', 'skilled-plugin' ),
					'description' => esc_html__( 'If set to Yes category list will be displayed instead of text.', 'skilled-plugin' ),
					'param_name'  => 'use_categories',
					'value'       => array(
						'No'  => '0',
						'Yes' => '1',
					),
				),
				array(
					'type'        => 'dropdown',
					'holder'      => '',
					'class'       => '',
					'admin_label' => true,
					'heading'     => esc_html__( 'Category', 'skilled-plugin' ),
					'param_name'  => 'category_id',
					'value'       => $course_category_arr,
					'description' => esc_html__( 'Category IDs are printed next to the category name. You can use this id number if you choose to use category search link shortcode in the editor bellow', 'skilled-plugin' ),
					'dependency'  => array( 'element' => 'use_categories', 'value' => '1' ),
				),
				array(
					'type'        => 'textfield',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Number of Subcategories', 'skilled-plugin' ),
					'param_name'  => 'number_of_subcategories',
					'description' => esc_html__( 'Number of subcategories to show. Please enter number only (0 means all)', 'skilled-plugin' ),
					'dependency'  => array( 'element' => 'use_categories', 'value' => '1' ),
				),
				array(
					'type'        => 'textfield',
					'holder'      => '',
					'class'       => '',
					'heading'     => esc_html__( 'Box Height', 'skilled-plugin' ),
					'param_name'  => 'box_height',
					'description' => esc_html__( 'Value in px. Enter number only.', 'skilled-plugin' )
				),
				array(
					'type'        => 'attach_image',
					'class'       => '',
					'heading'     => esc_html__( 'Background Image', 'skilled-plugin' ),
					'param_name'  => 'bg_image',
					'value'       => '',
					'description' => esc_html__( 'Upload background image.', 'skilled-plugin' )
				),
				array(
					'type'        => 'icon_manager',
					'class'       => '',
					'heading'     => esc_html__( 'Select Icon ', 'smile' ),
					'param_name'  => 'icon',
					'value'       => '',
					'description' => esc_html__( "Click and select icon of your choice. If you can't find the one that suits for your purpose, you can <a href='admin.php?page=font-icon-Manager' target='_blank'>add new here</a>.", 'flip-box' ),
				),
				array(
					'type'       => 'textarea_html',
					'class'      => '',
					'heading'    => esc_html__( 'Text', 'skilled-plugin' ),
					'param_name' => 'text',
					'value'      => '',
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Background Color', 'skilled-plugin' ),
					'param_name'  => 'bg_color',
					'value'       => '#FF6A6F',
					'description' => esc_html__( 'Set background color.', 'skilled-plugin' ),
					'group'       => 'Styling',
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Font Color', 'skilled-plugin' ),
					'param_name'  => 'font_color',
					'value'       => '#FFF',
					'group'       => 'Styling',
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Top Text Background Color', 'skilled-plugin' ),
					'param_name'  => 'top_text_bg_color',
					'value'       => '#FFF',
					'group'       => 'Styling',
				),
				array(
					'type'        => 'colorpicker',
					'class'       => '',
					'heading'     => esc_html__( 'Top Text Font Color', 'skilled-plugin' ),
					'param_name'  => 'top_text_font_color',
					'value'       => '#FF6A6F',
					'group'       => 'Styling',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html__( 'Extra class name', 'skilled-plugin' ),
					'param_name'  => 'el_class',
					'description' => esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'skilled-plugin' ),
				),
			)
		) );
	}

	public function load_css( $atts ) {

		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'box_height'              => 420,
			'bg_color'                => '#FF6A6F',
			'font_color'              => '#FFF',
			'font_family'             => '',
			'top_text_bg_color'       => '#FFF',
			'top_text_font_color'     => '#FF6A6F',
		), $atts ) );


		$style = '';

		/**
		 * Widget Style
		 */
		$widget_style = array(
			'height:' . (int) $box_height . 'px',
			"background-color:{$bg_color}",
			"color:{$font_color}",
		);
		$widget_style = implode( ';', $widget_style );
		$style .= ".{$uid} .course-category-widget{{$widget_style}}";

		/**
		 * Link Style
		 */
		$link_style = array(
			"background-color:{$top_text_bg_color}",
			"color:{$top_text_font_color}",
		);
		$link_style = implode( ';', $link_style );
		$style .= ".{$uid} .top-link span{{$link_style}}";

		if ( $style ) {
			wp_add_inline_style( 'skilled_options_style', $style );
		}
	}

	public function render( $atts, $content = null ) {
		$uid = Skilled_Plugin_Assets::get_uid( $this->namespace, $atts );

		extract( shortcode_atts( array(
			'bg_image'                => '',
			'top_title'               => '',
			'title'                   => '',
			'use_categories'          => '0',
			'category_id'             => '',
			'number_of_subcategories' => 0,
			'box_height'              => 420,
			'icon'                    => '',
			'text'                    => '',
			'bg_color'                => '#FF6A6F',
			'font_color'              => '#FFF',
			'font_family'             => '',
			'top_text_bg_color'       => '#FFF',
			'top_text_font_color'     => '#FF6A6F',
			'el_class'                => '',
		), $atts ) );

		$img = wp_get_attachment_image_src( $bg_image, 'large' );

		$args = array(
			'parent'   => $category_id, // only direct descendants
			'taxonomy' => 'course-category',
			'number'   => (int) $number_of_subcategories,
		);

		$categories = get_categories( $args );

		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'dntp-sensei-courses-category ' . $el_class, $this->namespace, $atts );
		$css_class .= ' ' . $uid;
		
		ob_start();
		?>
		<div class="<?php echo esc_attr( $css_class ); ?>">
			<div class="course-category-widget">
				<?php if ( $top_title ): ?>
					<div class="top-link">
						<span><?php echo esc_html( $top_title ); ?></span>
					</div>
				<?php endif; ?>
				<div class="icon-wrap">
					<i class="<?php echo esc_attr( $icon ); ?>"></i>
				</div>
				<?php if ( $title ): ?>
					<div class="title"><?php echo esc_html( $title ); ?></div>
				<?php endif; ?>
				<div class="text">
					<?php echo do_shortcode( $text ); ?>
					<?php if ( (int) $use_categories && $categories ): ?>
						<?php foreach ( $categories as $category ) : ?>
							<?php if ( is_object( $category ) ) : ?>
							<p>
								<a href="<?php echo esc_url( add_query_arg( array(
									's'               => '',
									'search-type'     => 'courses',
									'course-category' => $category->term_id
								), esc_url( get_site_url() ) ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
							</p>
							<?php endif; ?>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
				<?php if ( isset( $img[0] ) ): ?>
					<div class="img-bg-wrap">
						<img class="img-bg" src="<?php echo esc_url( $img[0] ); ?>"  alt="<?php esc_attr_e( 'Background image', 'skilled-plugin' ); ?>"/>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<?php
		return ob_get_clean();
	}

}

new Skilled_Plugin_VC_Addon_Sensei_Courses_Category();
