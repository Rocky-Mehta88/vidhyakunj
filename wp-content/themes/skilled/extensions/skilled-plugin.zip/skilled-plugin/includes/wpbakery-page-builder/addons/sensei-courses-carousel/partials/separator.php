<?php if ( (int) $show_separator): ?>
	<hr>
<?php endif; ?>
