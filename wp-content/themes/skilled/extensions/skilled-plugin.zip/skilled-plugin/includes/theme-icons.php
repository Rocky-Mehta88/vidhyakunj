<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_filter( 'vc_iconpicker-type-theme-icons', 'skilled_plugin_theme_icons' );
add_action( 'admin_menu', 'skilled_plugin_register_show_theme_icons_page' );
add_action( 'admin_enqueue_scripts', 'skilled_plugin_icons_page_style' );

function skilled_plugin_theme_icons( $icons ) {
    return array_merge( $icons, skilled_plugin_get_theme_icon_list() );
}

function skilled_plugin_get_theme_icons_for_elementor( $icons ) {
    foreach ( skilled_plugin_get_theme_icon_list() as $icon ) {
        $key = key( $icon );
        $icons[$key] = $key;
    }

    return $icons;
}

function skilled_plugin_show_theme_icons() {
    $icons = skilled_plugin_get_theme_icon_list();
    ?>
    <h1><?php esc_html_e( 'Theme Icons', 'skilled-plugin' ); ?></h1>
    <ul class="icons">
    <?php foreach ( $icons as $icon_data ): ?>
        <?php foreach ( $icon_data as $icon ): ?>
            <li><i class="<?php echo esc_attr( $icon ); ?>"></i> <?php echo esc_html( $icon ); ?></li>
        <?php endforeach ?>
    <?php endforeach ?>
    </ul>
    <?php
}

function skilled_plugin_icons_page_style( $hook ) {

    if ( $hook != 'tools_page_theme-icons' ) {
        return;
    }
    wp_enqueue_style( 'skilled-theme-icons', get_template_directory_uri() . '/assets/css/theme-icons.css', false );

    $custom_css = '.icons li{width: 30%;list-style:none;float: left;
    padding: 10px;}.icons li i{font-size:30px;margin-right: 15px;}';
    wp_add_inline_style( 'skilled-theme-icons', $custom_css );
}

function skilled_plugin_register_show_theme_icons_page() {
    add_submenu_page( 
        'tools.php',
        'Theme Icons',
        'Theme Icons',
        'manage_options',
        'theme-icons',
        'skilled_plugin_show_theme_icons'
    );
}

function skilled_plugin_get_theme_icon_list() {

	$theme_icons = array(
		array( 'icon-skilledadd-bolder' => 'icon-skilledadd-bolder' ),
        array( 'icon-skilledadd' => 'icon-skilledadd' ),
        array( 'icon-skilledminus' => 'icon-skilledminus' ),
        array( 'icon-skilledsubstract-light' => 'icon-skilledsubstract-light' ),
        array( 'icon-skilledsubstract' => 'icon-skilledsubstract' ),
        array( 'icon-skilledadd-bookmarks' => 'icon-skilledadd-bookmarks' ),
        array( 'icon-skilledbookmark-button' => 'icon-skilledbookmark-button' ),
        array( 'icon-skilledbook-with-bookmark' => 'icon-skilledbook-with-bookmark' ),
        array( 'icon-skilledcancel' => 'icon-skilledcancel' ),
        array( 'icon-skilledcopy-content' => 'icon-skilledcopy-content' ),
        array( 'icon-skilledcross-1' => 'icon-skilledcross-1' ),
        array( 'icon-skilledcross' => 'icon-skilledcross' ),
        array( 'icon-skilledcross-out' => 'icon-skilledcross-out' ),
        array( 'icon-skilledfile-folder' => 'icon-skilledfile-folder' ),
        array( 'icon-skilledplay-sign' => 'icon-skilledplay-sign' ),
        array( 'icon-skilledround-account-button-with-user-inside2' => 'icon-skilledround-account-button-with-user-inside 2'),
        array( 'icon-skilledround-favorite-button' => 'icon-skilledround-favorite-button' ),
        array( 'icon-skilledspeaker' => 'icon-skilledspeaker' ),
        array( 'icon-skilledgraduation-cap' => 'icon-skilledgraduation-cap' ),
        array( 'icon-skilledexternal-link-square' => 'icon-skilledexternal-link-square' ),
        array( 'icon-skilledf0c0' => 'icon-skilledf0c0' ),
        array( 'icon-skilledsend-o' => 'icon-skilledsend-o' ),
        array( 'icon-skilleduser-plus' => 'icon-skilleduser-plus' ),
        array( 'icon-skilledf058' => 'icon-skilledf058' ),
        array( 'icon-skilledf007' => 'icon-skilledf007' ),
        array( 'icon-skilledcreative-commons' => 'icon-skilledcreative-commons' ),
        array( 'icon-skilledfacetime-button' => 'icon-skilledfacetime-button' ),
        array( 'icon-skilledlight-bulb3' => 'icon-skilledlight-bulb3' ),
        array( 'icon-skilledmale-user-in-circular-button' => 'icon-skilledmale-user-in-circular-button' ),
        array( 'icon-skilledman-in-circular-interface-button' => 'icon-skilledman-in-circular-interface-button' ),
        array( 'icon-skilledpencil3' => 'icon-skilledpencil3' ),
        array( 'icon-skilledround-account-button-with-user-inside' => 'icon-skilledround-account-button-with-user-inside' ),
        array( 'icon-skilledtime4' => 'icon-skilledtime4' ),
        array( 'icon-skilledtrophy' => 'icon-skilledtrophy' ),
        array( 'icon-skillednumber1' => 'icon-skillednumber1' ),
        array( 'icon-skillednumber2' => 'icon-skillednumber2' ),
        array( 'icon-skillednumber3' => 'icon-skillednumber3' ),
        array( 'icon-skillednumber4' => 'icon-skillednumber4' ),
        array( 'icon-skilledagenda-one' => 'icon-skilledagenda-one' ),
        array( 'icon-skilledagenda' => 'icon-skilledagenda' ),
        array( 'icon-skilledamerican-football' => 'icon-skilledamerican-football' ),
        array( 'icon-skilledarrow' => 'icon-skilledarrow' ),
        array( 'icon-skilledbackpack' => 'icon-skilledbackpack' ),
        array( 'icon-skilledbadge' => 'icon-skilledbadge' ),
        array( 'icon-skilledbasketball' => 'icon-skilledbasketball' ),
        array( 'icon-skilledbell-one' => 'icon-skilledbell-one' ),
        array( 'icon-skilledbell' => 'icon-skilledbell' ),
        array( 'icon-skilledbig-church-bell' => 'icon-skilledbig-church-bell' ),
        array( 'icon-skilledbook-note' => 'icon-skilledbook-note' ),
        array( 'icon-skilledbook' => 'icon-skilledbook' ),
        array( 'icon-skilledbook-and-computer-mouse' => 'icon-skilledbook-and-computer-mouse' ),
        array( 'icon-skilledbook-with-white-bookmark' => 'icon-skilledbook-with-white-bookmark' ),
        array( 'icon-skilledbus' => 'icon-skilledbus' ),
        array( 'icon-skilledcalendar' => 'icon-skilledcalendar' ),
        array( 'icon-skilledcertification' => 'icon-skilledcertification' ),
        array( 'icon-skilledclock-one' => 'icon-skilledclock-one' ),
        array( 'icon-skilledclock' => 'icon-skilledclock' ),
        array( 'icon-skilledcustomer2' => 'icon-skilledcustomer2' ),
        array( 'icon-skilleddark-eye' => 'icon-skilleddark-eye' ),
        array( 'icon-skilleddiploma' => 'icon-skilleddiploma' ),
        array( 'icon-skillededit-draw-pencil' => 'icon-skillededit-draw-pencil' ),
        array( 'icon-skilledflask' => 'icon-skilledflask' ),
        array( 'icon-skilledfootball' => 'icon-skilledfootball' ),
        array( 'icon-skilledhtml2' => 'icon-skilledhtml2' ),
        array( 'icon-skilledicon' => 'icon-skilledicon' ),
        array( 'icon-skilledlight-bulb' => 'icon-skilledlight-bulb' ),
        array( 'icon-skilledmeasuring' => 'icon-skilledmeasuring' ),
        array( 'icon-skilledmedal3' => 'icon-skilledmedal3' ),
        array( 'icon-skilledmedal-one' => 'icon-skilledmedal-one' ),
        array( 'icon-skilledmedal' => 'icon-skilledmedal' ),
        array( 'icon-skilledmegaphone' => 'icon-skilledmegaphone' ),
        array( 'icon-skillednotification-bell' => 'icon-skillednotification-bell' ),
        array( 'icon-skilledpaint-palette' => 'icon-skilledpaint-palette' ),
        array( 'icon-skilledpencil' => 'icon-skilledpencil' ),
        array( 'icon-skilledplaceholder' => 'icon-skilledplaceholder' ),
        array( 'icon-skilledquality3' => 'icon-skilledquality3' ),
        array( 'icon-skilledribbon-badge-award' => 'icon-skilledribbon-badge-award' ),
        array( 'icon-skilledsaturn-rings' => 'icon-skilledsaturn-rings' ),
        array( 'icon-skilledschool' => 'icon-skilledschool' ),
        array( 'icon-skilledscissors' => 'icon-skilledscissors' ),
        array( 'icon-skilledsearch' => 'icon-skilledsearch' ),
        array( 'icon-skilledsharing-interface' => 'icon-skilledsharing-interface' ),
        array( 'icon-skilledsmall-camera' => 'icon-skilledsmall-camera' ),
        array( 'icon-skilledtactics' => 'icon-skilledtactics' ),
        array( 'icon-skilledtarget' => 'icon-skilledtarget' ),
        array( 'icon-skilledtime' => 'icon-skilledtime' ),
        array( 'icon-skilledtwo-quotes' => 'icon-skilledtwo-quotes' ),
        array( 'icon-skilledloupe1' => 'icon-skilledloupe1' ),
        array( 'icon-skilledmenu' => 'icon-skilledmenu' ),
        array( 'icon-skilledmenu-button' => 'icon-skilledmenu-button' ),
        array( 'icon-skilledmenu-lines' => 'icon-skilledmenu-lines' ),
        array( 'icon-skilledagenda2' => 'icon-skilledagenda2' ),
        array( 'icon-skilledamerican-football1' => 'icon-skilledamerican-football1' ),
        array( 'icon-skilledbadge2' => 'icon-skilledbadge2' ),
        array( 'icon-skilledbell-one2' => 'icon-skilledbell-one2' ),
        array( 'icon-skilledbook-one' => 'icon-skilledbook-one' ),
        array( 'icon-skilledbook-and-computer-mouse2' => 'icon-skilledbook-and-computer-mouse2' ),
        array( 'icon-skilledbus2' => 'icon-skilledbus2' ),
        array( 'icon-skilledcustomer3' => 'icon-skilledcustomer3' ),
        array( 'icon-skillededit-draw-pencil2' => 'icon-skillededit-draw-pencil2' ),
        array( 'icon-skilledfootball2' => 'icon-skilledfootball2' ),
        array( 'icon-skilledmedal1' => 'icon-skilledmedal1' ),
        array( 'icon-skilledpencil2' => 'icon-skilledpencil2' ),
        array( 'icon-skilledscissors2' => 'icon-skilledscissors2' ),
        array( 'icon-skilledbook1' => 'icon-skilledbook1' ),
        array( 'icon-skilledcalendar22' => 'icon-skilledcalendar22' ),
        array( 'icon-skilledribbon' => 'icon-skilledribbon' ),
	);

	return $theme_icons;
}
