<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'widgets_init', 'skilled_plugin_register_wp_widgets' );
add_filter( 'msm_filter_vc_addons', 'skilled_plugin_msm_filter_vc_addons' );

/**
 * Save Sensei Settings the first time
 */
add_option( 'woothemes-sensei-settings', array(
	'course_archive_image_width'     => 260,
	'course_archive_image_height'    => 170,
	'course_archive_image_hard_crop' => true,
	'course_lesson_image_enable'     => true,
	'lesson_archive_image_width'     => 100,
	'lesson_archive_image_height'    => 70,
	'lesson_archive_image_hard_crop' => true,
	'lesson_single_image_enable'     => true,
	'lesson_single_image_width'      => 835,
	'lesson_single_image_height'     => 500,
	'lesson_single_image_hard_crop'  => true,
	'woocommerce_enabled'            => true,
	'course_single_content_display'  => 'full',
) );

$skilled_plugin_includes = array(
	'includes/functions.php',
	'includes/shortcodes.php',
	'includes/theme-icons.php',
	'includes/assets.php',
	'includes/layout-blocks/init.php',
	'extensions/teacher-post-type/teacher-post-type.php',
);

if ( defined( 'WPB_VC_VERSION' ) ) {
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/init.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/content-box/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/dribbble-shots/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/logo/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/menu/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/post-list/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/quick-sidebar-trigger/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/search/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/share-this/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/theme-button/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/theme-icon/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/theme-map/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/video-popup/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/wc-mini-cart/addon.php';

	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/events/events.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/our-process/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/countdown/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/ribbon/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/courses-search-form/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/sensei-courses-carousel/addon.php';
	$skilled_plugin_includes[] = 'includes/wpbakery-page-builder/addons/sensei-courses-category/addon.php';
}

foreach ( $skilled_plugin_includes as $file ) {
	$filepath = plugin_dir_path( dirname( __FILE__ ) ) . $file;
	if ( ! file_exists( $filepath ) ) {
		trigger_error( sprintf( esc_html__( 'Error locating %s for inclusion', 'skilled-plugin' ), $file ), E_USER_ERROR );
	}
	require_once $filepath;
}
unset( $file, $filepath );

function skilled_plugin_register_wp_widgets() {
	require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/wp-widgets/latest-posts-widget.php';
	require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/wp-widgets/contact-info-widget.php';
	require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/wp-widgets/working-hours-widget.php';
	require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/wp-widgets/teachers-widget.php';

	if ( function_exists( 'Sensei' ) ) {
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/wp-widgets/sensei-course-component.php';
	}
}

function skilled_plugin_msm_filter_vc_addons( $addons ) {
	return array( 'mega-menu-content-box/addon.php' );
}
