<div class="jsjr-pci-accordion-item" data-id="profile_image">
	<h3 class="jsjr-pci-toggle" ><?php esc_html_e( 'Profile Photo', 'skilled-plugin' ); ?></h3>
	<div style="display:none;" >
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'profile_image_url' ) ); ?>"><?php esc_html_e( 'Link to Profile Image (URL): ', 'skilled-plugin' ); ?></label> 
			<input class="widefat upload-input" id="<?php echo esc_attr( $this->get_field_id( 'profile_image_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'profile_image_url' ) ); ?>" type="text" value="<?php esc_html_e( isset( $profile_image_url ) ?  $profile_image_url : '', 'skilled-plugin' ); ?>" />
			<input type="button" name="submit" id="submit" class="button-primary upload-button" value="Select image" rel="<?php echo esc_attr( $this->get_field_id( 'profile_image_url' ) ); ?>">
			
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'profile_image' ) ); ?>"><?php esc_html_e( 'Image Style:' ); ?></label>
			<a href="#" class="jsjr-pci-question" title="<?php esc_attr_e( 'NOTICE: These styles do not work on old internet browsers.', 'skilled-plugin' ) ?>">?</a>
			<select name="<?php echo esc_attr( $this->get_field_name( 'profile_image' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'profile_image' ) ); ?>" class="widefat">
				<?php
				$profile_image = isset( $profile_image ) ? $profile_image : '';
				foreach ( $select_options as $key => $value ) {
					echo '<option value="' , esc_attr( $key ) , '" ', selected( $profile_image, $key ) , '>', esc_html__( $value, 'skilled-plugin' ) , '</option>';
				}
				?>
			</select>
		</p>
	</div>
</div>