<div class="jsjr-pci-accordion-item" data-id="social_media_links">
	<h3 class="jsjr-pci-toggle" ><?php esc_html_e('Social Media Links', 'skilled-plugin' ); ?></h3>
	<div style="display:none;">
		<a href="#" class="jsjr-pci-question" title="<?php esc_attr_e( 'Enter the internet links (URL) for your social media websites below (I.E \'http://facebook.com/myfacebookpage\')', 'skilled-plugin' ) ?>" >?</a>
		<?php foreach ( $this->social_icons as $fa_class => $icon ) { ?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( $fa_class ) ); ?>"><?php esc_html_e( $icon.':', 'skilled-plugin' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $fa_class ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $fa_class ) ); ?>" type="text" value="<?php esc_attr_e( isset( $$fa_class ) ?  $$fa_class : '', 'skilled-plugin' ); ?>" />
			<label for="<?php echo esc_attr( $this->get_field_id( $fa_class . '_custom_image' ) ); ?>"><?php echo sprintf( esc_html__( 'Custom %s icon:', 'skilled-plugin' ),  $icon ); ?></label>
			<?php $custom_image_name = $fa_class . '_custom_image'; ?>
			<input class="widefat upload-input" id="<?php echo esc_attr( $this->get_field_id( $custom_image_name ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $custom_image_name ) ); ?>" type="text" value="<?php esc_attr_e( isset( $$custom_image_name ) ?  $$custom_image_name : '', 'skilled-plugin' ); ?>" />
			<input type="button" name="submit" id="submit" class="button-primary upload-button" value="Select image" rel="<?php echo esc_attr( $this->get_field_id( $custom_image_name ) ); ?>">
		</p>
		<?php } ?>								
	</div>
</div>