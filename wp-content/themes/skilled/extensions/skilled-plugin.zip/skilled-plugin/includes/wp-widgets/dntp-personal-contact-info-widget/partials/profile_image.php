<?php
if ( ! empty( $profile_image_url ) && ! empty( $profile_image ) ) {
	if ( $profile_image_below  === 'unchecked' ) {
		echo '<img src="' , esc_url( $profile_image_url ) , '" class="jsjr-pci-photo ', esc_attr( $profile_image ), '" alt="Profile Photo" />';
	} 
} 