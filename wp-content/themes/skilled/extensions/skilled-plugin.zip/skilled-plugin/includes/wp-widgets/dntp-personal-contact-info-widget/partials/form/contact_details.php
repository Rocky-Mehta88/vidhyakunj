<div class="jsjr-pci-accordion-item" data-id="contact_details">
	<h3 class="jsjr-pci-toggle" ><?php esc_html_e('Contact Details', 'skilled-plugin' ); ?></h3>
	<div style="display:none;" >
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'full_name' ) ); ?>"><?php esc_html_e( 'Your Full Name:' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'full_name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'full_name' ) ); ?>" type="text" value="<?php esc_html_e( isset( $full_name ) ?  $full_name : '', 'skilled-plugin' ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'slogan' ) ); ?>"><?php esc_html_e( 'Slogan:' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'slogan' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name('slogan') ); ?>" type="text" value="<?php esc_html_e( isset( $slogan ) ?  $slogan : '', 'skilled-plugin' ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>"><?php esc_html_e( 'Email:' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" value="<?php esc_html_e( isset( $email ) ?  $email : '', 'skilled-plugin' ); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>"><?php esc_html_e( 'Phone:' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" value="<?php esc_html_e( isset( $phone ) ?  $phone : '', 'skilled-plugin' ); ?>" />
		</p>			
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'website' ) ); ?>"><?php esc_html_e( 'Alternate Website (optional):', 'skilled-plugin' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'website' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'website' ) ); ?>" type="text" value="<?php esc_html_e( isset( $website ) ?  $website : '', 'skilled-plugin' ); ?>" />
		</p>
	</div>
</div>