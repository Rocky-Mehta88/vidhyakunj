<?php

$l10n_ls_slider_library = array(

	'WindowTitle' 		=> __('Choose LayerSlider', 'LayerSlider'),
	'WindowLoading' 	=> __('Loading sliders ...', 'LayerSlider'),
	'SelectButton' 		=> __('Select', 'LayerSlider'),
	'NoPreview' 		=> __('No Preview', 'LayerSlider'),
	'NoPreviewText' 	=> __('Previews are automatically generated from slide images in sliders.', 'LayerSlider')
);